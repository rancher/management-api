from distutils.core import setup

setup(
    name='IntegrationTests',
    version='0.1',
    packages=[
      'core',
    ],
    license='ASL 2.0',
    long_description=open('README.txt').read(),
)
