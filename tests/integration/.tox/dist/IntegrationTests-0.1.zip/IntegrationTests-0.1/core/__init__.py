import pytest

pytest.register_assert_rewrite('core.common_fixtures')
